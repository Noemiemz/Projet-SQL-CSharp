DROP DATABASE IF EXISTS Bellefleur; 
CREATE DATABASE IF NOT EXISTS Bellefleur; 
USE Bellefleur;

-- création de la table client
CREATE TABLE client 
(idclient INT NOT NULL,
idadresse INT,
nomclient varchar(30), 
prenomclient varchar(30), 
telephone varchar(15), 
mail varchar(50), 
mdp varchar(20), 
cartecredit varchar(30), 
nbcommande int, 
fidelite varchar(20), 
reduction int ); 

-- création de la table adresse
CREATE TABLE adresse 
(idadresse INT NOT NULL, 
codepostal int, 
ville varchar(50), 
rue varchar(50), 
numero int);  

-- création de la table produit
CREATE TABLE produit
(idproduit INT NOT NULL,
nomproduit varchar(30),
prix float,
disponibilite varchar(30),
quantite int,
typeproduit varchar(20)); 

-- création de la table arrangement 
CREATE TABLE arrangement 
(idarrangement INT NOT NULL, 
nomarrangement varchar(30), 
prixarrangement float, 
categorie varchar(30), 
typearrangement varchar(30)); 

-- création de la table commande 
CREATE TABLE commande 
(idcommande INT NOT NULL, 
idclient INT, 
idarrangement INT, 
idadresse INT, 
idmagasin INT, 
datecommande datetime, 
statutcommande varchar(30), 
etatcommande varchar(10), 
message text, 
datelivraison datetime);  

-- création de la table magasin
CREATE TABLE magasin 
(idmagasin INT NOT NULL, 
nommagasin varchar(30), 
chiffreaffaire float);  

-- création de la table stock
CREATE TABLE stock 
(idstock INT NOT NULL, 
stock_min int, 
stock_max int, 
stockactuel int);  
 

-- création de la table est_compose_de
CREATE TABLE est_compose_de (idarrangement int NOT NULL, idproduit int NOT NULL);  

-- création de la table est_en_stock
CREATE TABLE est_en_stock (idstock int NOT NULL, idproduit int NOT NULL);

-- création de la table a_comme_stock
CREATE TABLE a_comme_stock (idmagasin int NOT NULL, idstock int NOT NULL);


-- clés primaires
ALTER TABLE client ADD CONSTRAINT PK_client PRIMARY KEY (idclient);  
ALTER TABLE adresse ADD CONSTRAINT PK_adresse PRIMARY KEY (idadresse);  
ALTER TABLE produit ADD CONSTRAINT PK_produit PRIMARY KEY (idproduit);  
ALTER TABLE arrangement ADD CONSTRAINT PK_arrangement PRIMARY KEY (idarrangement);  
ALTER TABLE commande ADD CONSTRAINT PK_commande PRIMARY KEY (idcommande);  
ALTER TABLE magasin ADD CONSTRAINT PK_magasin PRIMARY KEY (idmagasin);  
ALTER TABLE stock ADD CONSTRAINT PK_stock PRIMARY KEY (idstock);  
ALTER TABLE est_compose_de ADD CONSTRAINT PK_est_compose_de PRIMARY KEY (idarrangement, idproduit);  
ALTER TABLE est_en_stock ADD CONSTRAINT PK_est_en_stock PRIMARY KEY (idstock, idproduit); 
ALTER TABLE a_comme_stock ADD CONSTRAINT PK_a_comme_stock PRIMARY KEY (idmagasin, idstock);

-- clés étrangères
ALTER TABLE client ADD CONSTRAINT FK_client_idadresse FOREIGN KEY (idadresse) REFERENCES adresse (idadresse);  
ALTER TABLE commande ADD CONSTRAINT FK_commande_idclient FOREIGN KEY (idclient) REFERENCES client (idclient);  
ALTER TABLE commande ADD CONSTRAINT FK_commande_idarrangement FOREIGN KEY (idarrangement) REFERENCES arrangement (idarrangement);  
ALTER TABLE commande ADD CONSTRAINT FK_commande_idadresse FOREIGN KEY (idadresse) REFERENCES adresse (idadresse);  
ALTER TABLE commande ADD CONSTRAINT FK_commande_idmagasin FOREIGN KEY (idmagasin) REFERENCES magasin (idmagasin);  
ALTER TABLE est_compose_de ADD CONSTRAINT FK_est_compose_de_idarrangement FOREIGN KEY (idarrangement) REFERENCES arrangement (idarrangement);  
ALTER TABLE est_compose_de ADD CONSTRAINT FK_est_compose_de_idproduit FOREIGN KEY (idproduit) REFERENCES produit (idproduit);  
ALTER TABLE est_en_stock ADD CONSTRAINT FK_est_en_stock_idstock FOREIGN KEY (idstock) REFERENCES stock (idstock);  
ALTER TABLE est_en_stock ADD CONSTRAINT FK_est_en_stock_idproduit FOREIGN KEY (idproduit) REFERENCES produit (idproduit);
ALTER TABLE a_comme_stock ADD CONSTRAINT FK_a_comme_stock_idmagasin FOREIGN KEY (idmagasin) REFERENCES magasin (idmagasin);  
ALTER TABLE a_comme_stock ADD CONSTRAINT FK_a_comme_stock_idstock FOREIGN KEY (idstock) REFERENCES stock (idstock);

-- insertion de lignes dans la table adresse
INSERT INTO Adresse 
VALUES (1, 75001, 'Paris', 'Rue de Rivoli', 1),
(2, 75002, 'Paris', 'Rue Montorgueil', 10),
(3, 75003, 'Paris', 'Rue de Bretagne', 22),
(4, 75004, 'Paris', 'Rue des Rosiers', 8),
(5, 75005, 'Paris', 'Rue Monge', 27),
(6, 75006, 'Paris', 'Rue Bonaparte', 15),
(7, 75007, 'Paris', 'Rue de Grenelle', 20),
(8, 75008, 'Paris', 'Avenue des Champs-Elysées', 76),
(9, 75009, 'Paris', 'Rue La Fayette', 100),
(10, 75010, 'Paris', 'Rue du Faubourg Saint-Martin', 35),
(11, 75011, 'Paris', 'Rue Oberkampf', 40),
(12, 75012, 'Paris', 'Avenue Daumesnil', 120),
(13, 75013, 'Paris', 'Boulevard Vincent Auriol', 23),
(14, 75014, 'Paris', 'Rue Daguerre', 12),
(15, 75015, 'Paris', 'Rue Lecourbe', 150);



-- insertion de lignes dans la table client
INSERT INTO Client 
VALUES (1, 1, 'Dubois', 'Sophie', '0665364789', 'sophie.dubois@mail.com', 'azerty', '1234567890123456', 5, 'bronze', 5),
(2, 1, 'Martin', 'Lucas', '0678453125', 'lucas.martin@mail.com', 'qwerty', '2345678901234567', 3, 'standard', 0),
(3, 3, 'Durand', 'Pierre', '0645789623', 'pierre.durand@mail.com', 'azertyuiop', '3456789012345678', 10, 'or', 15),
(4, 4, 'Dupont', 'Emilie', '0612547896', 'emilie.dupont@mail.com', 'azerty123', '4567890123456789', 2, 'standard', 0),
(5, 5, 'Lefebvre', 'Antoine', '0632147859', 'antoine.lefebvre@mail.com', 'qsdfgh', '5678901234567890', 3, 'bronze', 5),
(6, 6, 'Moreau', 'Julie', '0687452369', 'julie.moreau@mail.com', 'azertyuiop123', '6789012345678901', 7, 'or', 15),
(7, 3, 'Roux', 'Nicolas', '0678954123', 'nicolas.roux@mail.com', 'azerty12345', '7890123456789012', 0, 'standard', 0),
(8, 8, 'Fournier', 'Marine', '0625364879', 'marine.fournier@mail.com', 'qsdfghjkl', '8901234567890123', 1, 'bronze', 5),
(9, 9, 'Girard', 'Maxime', '0678459652', 'maxime.girard@mail.com', 'azertyuiop456', '9012345678901234', 6, 'or', 15),
(10, 15, 'Andre', 'Julien', '0645789652', 'julien.andre@mail.com', 'azerty123456', '1234567890123456', 3, 'standard', 0),
(11, 11, 'Caron', 'Marie', '0678953214', 'marie.caron@mail.com', 'qsdfghjklm', '2345678901234567', 2, 'bronze', 5),
(12, 12, 'Moulin', 'Lucie', '0632478596', 'lucie.moulin@mail.com', 'azertyuiop789', '3456789012345678', 5, 'or', 15),
(13, 13, 'Noel', 'Hugo', '0678956321', 'hugo.noel@mail.com', 'azerty1234567', '4567890123456789', 2, 'standard', 0),
(15, 3, 'Lemoine', 'Thomas', '0687459632', 'thomas.lemoine@mail.com', 'qsdfghjkl123', '5678901234567890', 4, 'bronze', 5),
(16, 5, 'Berger', 'Laura', '0612547896', 'laura.berger@mail.com', 'azertyuiop123456', '6789012345678901', 5, 'or', 15),
(17, 8, 'Gauthier', 'Antoine', '0632147859', 'antoine.gauthier@mail.com', 'qsdfgh123', '7890123456789012', 2, 'standard', 0),
(18, 11, 'Dupuis', 'Lucie', '0678954123', 'lucie.dupuis@mail.com', 'azerty456', '8901234567890123', 2, 'bronze', 5),
(19, 7, 'Chevalier', 'Nicolas', '0625364879', 'nicolas.chevalier@mail.com', 'qsdfghjkl456', '9012345678901234', 6, 'or', 15),
(20, 14, 'Benoit', 'Marie', '0678459652', 'marie.benoit@mail.com', 'azertyuiop4567', '1234567890123456', 0, 'standard', 0),
(21, 14, 'David', 'Julien', '0645789652', 'julien.david@mail.com', 'azerty1234567', '2345678901234567', 1, 'bronze', 5);



-- insertion de lignes dans la table magasin
INSERT INTO Magasin 
VALUES (0, 'Magasin A', 150000.50),
(1, 'Magasin B', 225000.75),
(2, 'Magasin C', 99000.25),
(3, 'Magasin D', 187500.00),
(4, 'Magasin E', 1500.00);

-- insertion de lignes dans la table produit
INSERT INTO Produit 
VALUES (1, 'Rose', 2.50, '0000',6,'fleur'),
(2, 'Lys', 3.20, '0608',5,'fleur'),
(3, 'Tulipe', 1.80, '1102',6,'fleur'),
(4, 'Marguerite', 2.00, '0000',6,'fleur'),
(5, 'Orchidée', 4.50, '0307',7,'fleur'),
(6, 'Hortensia', 3.75, '0511',5,'fleur'),
(7, 'Lilas', 2.90, '1104',8,'fleur'),
(8, 'Pivoine', 4.20, '0000',6,'fleur'),
(9, 'Dahlia', 2.70, '0912',7,'fleur'),
(10, 'Œillet', 1.90, '0306',7,'fleur'),
(11, 'Jonquille', 1.50, '0305',5,'fleur'),
(12, 'Bleuet', 1.25, '1001',9,'fleur'),
(13,'Gerbera', 5.00, '0000',7,'fleur'),
(14, 'Ginger' ,4.00, '0000',6,'fleur'),
(15,'Glaïeul',1.00, '0511',8,'fleur'),
(16, 'Marguerite', 2.25,'0000',10,'fleur'),
(17, 'Vase en verre', 5.99,null,1,'accessoire'),
(18, 'Ruban de satin', 2.50,null,1,'accessoire'),
(19, 'Panier en osier', 7.25,null,1,'accessoire'),
(20, 'Bougie parfumée', 4.99,null,1,'accessoire'),
(21, 'Bouquet de plumes', 7.99,null,1,'accessoire'),
(22, 'Nœud en organza', 1.99,null,1,'accessoire'),
(23, 'Ruban adhésif décoratif', 2.99,null,1,'accessoire'),
(24, 'Papier de soie', 1.50,null,1,'accessoire'),
(25, 'Vase en céramique', 8.99,null,1,'accessoire');

-- insertion des lignes dans la table arrangement
INSERT INTO arrangement
VALUES (1,'Gros Merci', 45, 'Toute occasion','standard'),
(2,'L’amoureux',65,'St-Valentin','standard'),
(3,'L’Exotique',40,'Toute occasion', 'standard'),
(4,'Maman', 80,'Fête des mères', 'standard'),
(5, 'Vive la mariée',120,'Mariage', 'standard'),
(6,'Fête des pères', 70, 'Fête des pères','standard'),
(7,'Anniversaire',50,'Anniversaire','standard'),
(8,'Le printemps', 55,'Toute occasion','standard'),
(9,'Pâques', 45,'Pâques','standard'),
(10, 'Tendre câlin',90,'Toute occasion','standard'),
(11,'Je suis désolé', 60, 'Excuses','standard'),
(12,'L’Automne',45,'Toute occasion','standard'),
(13,'Joyeux Noël', 85,'Noël','standard'),
(14,'Nouvel an', 80,'Nouvel an','standard'),
(15, 'Bébé',70,'Naissance','standard');

-- insertion de lignes dans la table commande
insert into commande
values 
(1, 5, 10, 8,  3, '2023-04-25 14:30:00', "standard", "VINV","bisou", '2023-05-01 10:00:00'),
(2, 17, 8, 6, 1, '2023-04-25 16:45:00', "personnalisée", "CC", "merci", '2023-04-29 16:00:00'),
(3, 9, 14, 13, 2, '2023-04-25 18:00:00', "personnalisée", "CAL", "meilleur voeux", '2023-04-28 11:30:00'),
(4, 7, 3, 4,  4, '2023-04-25 19:15:00', "standard", "VINV", "je t'aime",  '2023-04-27 12:00:00'),
(5, 18, 12, 11, 3, '2023-04-25 21:30:00', "standard",  "CPAV", "ntm",  '2023-04-30 14:00:00'),
(6, 3, 1, 9,  2,  '2023-04-26 08:00:00',  "personnalisée", "CL",  "félicitations", '2023-04-28 16:30:00'),
(7, 5, 6, 14,1, '2023-02-26 09:15:00', "standard", "VINV","à bientôt", '2023-03-02 09:00:00'),
(8, 12, 5, 7, 3, '2023-02-26 10:30:00', 'personnalisée', 'CAL', 'joyeux anniversaire', '2023-03-01 18:00:00'),
(9, 5, 13, 4, 2, '2023-03-26 12:45:00', 'standard', 'VINV', 'bonne fête maman', '2023-04-01 10:30:00'),
(10, 18, 1, 3, 4, '2023-04-26 14:00:00', 'personnalisée', 'CC', 'félicitations pour ton diplôme', '2023-05-02 14:00:00'),
(11, 5, 11, 14, 1, '2023-01-06 16:15:00', 'standard', 'VINV', 'merci pour tout', '2023-01-15 12:30:00'),
(12, 9, 7, 9, 3, '2023-04-27 09:00:00', 'standard', 'CPAV', 'joyeuses pâques', '2023-04-30 16:00:00'),
(13, 10, 2, 6, 1, '2023-04-27 10:15:00', 'personnalisée', 'CL', 'bon rétablissement', '2023-05-02 11:00:00'),
(14, 9, 14, 2, 2, '2023-04-27 11:30:00', 'standard', 'VINV', 'je suis désolé', '2023-05-01 17:00:00'),
(15, 5, 9, 12, 3, '2023-01-27 13:45:00', 'personnalisée', 'CAL', 'bonne continuation', '2023-02-03 15:30:00'),
(16, 7, 6, 11, 4, '2023-04-27 15:00:00', 'standard', 'VINV', 'joyeux noël', '2023-12-25 12:00:00'),
(17, 6, 12, 8, 2, '2023-01-01 17:15:00', 'personnalisée', 'CC', 'bonne année', '2023-01-02 10:00:00');


-- insertion de lignes dans la table stock
insert into stock
values (1,15,84,52),(2,11,93,75),(3,18,84,32),(4,17,80,63),(5,12,99,42),(6,20,93,52),(7,19,97,69),(8,11,92,84),(9,12,85,1),(10,11,81,60),(11,15,90,82),(12,13,95,53),
(13,13,81,56),(14,20,80,13),(15,13,100,4),(16,19,90,86),(17,18,84,42),(18,17,100,33),(19,11,98,8),(20,17,97,48),(21,14,98,73),(22,15,97,39),(23,20,96,79),(24,12,92,82),(25,12,89,49),(26,17,96,65),(27,18,99,99),(28,17,100,51),(29,20,90,8),(30,19,91,87),(31,20,91,62),(32,19,87,5),(33,11,94,94),(34,18,91,55),(35,10,87,19),(36,12,100,65),(37,15,86,77),(38,11,91,59),(39,16,94,63),(40,19,82,10),(41,16,89,71),(42,14,89,51),(43,18,100,1),(44,12,94,6),(45,20,81,37),(46,12,84,15),(47,15,88,11),(48,20,89,76),
(49,14,100,30),(50,19,90,70),(51,13,95,79),(52,18,82,79),(53,17,85,47),(54,12,82,8),(55,10,89,61),(56,11,88,30),(57,19,90,8),(58,11,83,32),(59,13,94,63),(60,10,96,59),
(61,19,92,2),(62,20,95,60),(63,15,85,42),(64,19,80,27),(65,20,83,68),(66,12,95,67),(67,18,88,69),(68,15,99,97),(69,17,83,72),(70,11,95,46),(71,18,80,38),(72,11,94,17),
(73,19,89,43),(74,11,99,10),(75,16,80,24),(76,14,86,24),(77,12,96,93),(78,11,89,21),(79,12,88,15),(80,16,100,53),(81,13,91,74),(82,13,92,11),(83,10,93,32),(84,11,93,55),(85,15,97,42),(86,11,91,36),(87,17,89,5),(88,12,94,59),(89,20,83,67),(90,15,85,69),(91,14,97,58),(92,16,99,92),(93,18,88,25),(94,17,88,8),(95,20,84,9),(96,11,82,60),
(97,16,84,73),(98,20,85,78),(99,17,91,17),(100,18,80,27),(101,18,96,96),(102,20,90,79),(103,14,92,63),(104,18,97,28),(105,20,91,12),(106,19,80,74),(107,17,97,22),
(108,16,85,36),(109,13,92,61),(110,17,99,88),(111,20,94,2),(112,13,95,24),(113,18,99,58),(114,17,84,8),(115,15,86,25),(116,19,85,43),(117,12,88,47),(118,10,83,43),
(119,19,81,18),(120,10,93,64),(121,20,80,55),(122,14,83,51),(123,10,81,45),(124,12,96,52),(125,18,84,18);

-- insertion des lignes dans la table est_en_stock
INSERT INTO est_en_stock VALUES 
(1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13),(14,14),(15,15),(16,16),(17,17),(18,18),(19,19),(20,20),(21,21),(22,22),(23,23),
(24,24),(25,25),(26,1),(27,2),(28,3),(29,4),(30,5),(31,6),(32,7),(33,8),(34,9),(35,10),(36,11),(37,12),(38,13),(39,14),(40,15),(41,16),(42,17),(43,18),(44,19),(45,20),
(46,21),(47,22),(48,23),(49,24),(50,25),(51,1),(52,2),(53,3),(54,4),(55,5),(56,6),(57,7),(58,8),(59,9),(60,10),(61,11),(62,12),(63,13),(64,14),(65,15),(66,16),(67,17),
(68,18),(69,19),(70,20),(71,21),(72,22),(73,23),(74,24),(75,25),(76,1),(77,2),(78,3),(79,4),(80,5),(81,6),(82,7),(83,8),(84,9),(85,10),(86,11),(87,12),(88,13),(89,14),
(90,15),(91,16),(92,17),(93,18),(94,19),(95,20),(96,21),(97,22),(98,23),(99,24),(100,25),(101,1),(102,2),(103,3),(104,4),(105,5),(106,6),(107,7),(108,8),(109,9),(110,10),(111,11),(112,12),(113,13),(114,14),(115,15),(116,16),(117,17),(118,18),(119,19),(120,20),(121,21),(122,22),(123,23),(124,24),(125,25);

-- insertion des lignes dans la table a_comme_stock 
insert into a_comme_stock values
(0,1),(0,2),(0,3),(0,4),(0,5),(0,6),(0,7),(0,8),(0,9),(0,10),(0,11),(0,12),(0,13),(0,14),(0,15),(0,16),(0,17),(0,18),(0,19),(0,20),(0,21),(0,22),(0,23),(0,24),(0,25),
(1,26),(1,27),(1,28),(1,29),(1,30),(1,31),(1,32),(1,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,39),(1,40),
(1,41),(1,42),(1,43),(1,44),(1,45),(1,46),(1,47),(1,48),(1,49),(1,50),(2,51),
(2,52),(2,53),(2,54),(2,55),(2,56),(2,57),(2,58),(2,59),(2,60),(2,61),(2,62),(2,63),(2,64),(2,65),(2,66),(2,67),(2,68),(2,69),(2,70),(2,71),(2,72),(2,73),(2,74),(2,75),
(3,76),(3,77),(3,78),(3,79),(3,80),(3,81),(3,82),(3,83),(3,84),(3,85),(3,86),(3,87),(3,88),(3,89),(3,90),(3,91),(3,92),(3,93),(3,94),(3,95),(3,96),(3,97),(3,98),(3,99),
(3,100),(4,101),(4,102),(4,103),(4,104),(4,105),(4,106),(4,107),(4,108),(4,109),(4,110),(4,111),(4,112),(4,113),(4,114),(4,115),(4,116),
(4,117),(4,118),(4,119),(4,120),(4,121),(4,122),(4,123),(4,124),(4,125);

-- insertion des lignes dans la table est_compose_de 
INSERT INTO est_compose_de VALUES 
(1,4),(1,6),(1,9),(1,10),(1,11),(1,14),(2,2),(2,3),(2,6),(2,7),(2,9),(2,10),(3,1),
(3,3),(3,6),(3,7),(3,8),(3,9),(4,1),(4,2),(4,3),(4,6),(4,8),(4,9),(5,1),(5,2),(5,5),
(5,9),(5,11),(5,14),(6,1),(6,2),(6,3),(6,6),(6,9),(6,10),(7,1),(7,3),(7,5),(7,6),(7,8),
(7,9),(8,1),(8,4),(8,6),(8,7),(8,11),(8,13),(9,2),(9,4),(9,6),(9,9),(9,10),(9,15),(10,1),
(10,4),(10,5),(10,7),(10,9),(10,10),(11,3),(11,4),(11,5),(11,7),(11,8),(11,13),(12,1),(12,2),
(12,4),(12,7),(12,8),(12,14),(13,1),(13,5),(13,6),(13,9),(13,12),(13,14),(14,1),(14,2),(14,3),
(14,5),(14,7),(14,9),(15,1),(15,3),(15,7),(15,8),(15,11),(15,16);